// Übung 13: Sechs Dateien einlesen

// Erstelle die Dateien file1.txt … file6.txt und lies sie, wie soeben beschrieben, mit getFileContent(…) aus Codebeispiel 117 ein.

// Was passiert, wenn eine Datei fehlt? Überprüfe die Fehlerbehandlung. Erweitere die Fehlermeldung so, dass ausgegeben wird, welche Dateien nicht gelesen werden konnten!
