// Übung 6: Aller Anfang ist leicht!

// Öffne einen Codeeditor deiner Wahl. Öffne ein Terminalfenster und navigiere in den Ordner, den du mit dem Codeeditor geöffnet hast. Installiere in diesem Ordner lokal das Package express in der Version 4.17.*.

// Übung 7: Packages aktualisieren
// In der letzten Übung hast du Express in der Version 4.17.* installiert. Um auf dem neuesten Stand zu sein, soll nun allerdings die aktuellste Version verwendet werden. Aktualisiere Express auf die neuste Version, ohne es zu deinstallieren.
