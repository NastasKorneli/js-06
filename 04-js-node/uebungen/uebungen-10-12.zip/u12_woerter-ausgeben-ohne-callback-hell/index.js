const sentence = 'The pyramid of doom growing.';

setTimeout(() => {
  console.log('The');

  setTimeout(() => {
    console.log('pyramid');

    setTimeout(() => {
      console.log('of');

      setTimeout(() => {
        console.log('doom');

        setTimeout(() => {
          console.log('keeps');

          setTimeout(() => {
            console.log('growing.');
          }, 1000);
        }, 1000);
      }, 1000);
    }, 1000);
  }, 1000);
}, 1000);

// Übung 12: Die Pyramide abbrechen

// Schreibe das Codebeispiel 89 so um, dass keine Pyramide entsteht. Benutze dazu, wie im Text angedeutet, eine Funktion, die das n-te Wort ausgibt und sich per setTimeout(…) mit n + 1 als Parameter aufruft, solange noch Wörter im Satz vorhanden sind.
