// Übung 10: CSV parsen mit einem Modul
// In Lektion 2 haben wir eine CSV Datei ausgelesen und später manuell in eine Objekt-Struktur umgewandelt. Das manuelle Parsen von CSV-Dateien kann jedoch sehr aufwändig und fehleranfällig sein, insbesondere bei großen Dateien mit vielen Spalten und Zeilen. In dieser Übung soll daher ein externes Modul verwendet werden, um eine CSV-Datei zu parsen und in eine JSON-Struktur umzuwandeln.

// Suche nach einem passenden Modul und wandle über das Modul die csv- Datei products.csv in eine json Struktur um.

// [
//   {
//     "code": "MUG0007",
//     "shortDescription": "coffee mug with LCD level indicator",
//     "tagline": "never again reach for the empty mug",
//     "quantity": 20,
//     "price": 49.90
//   },
//   { ... }
// ]
