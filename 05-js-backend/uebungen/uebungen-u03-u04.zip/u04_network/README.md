Übung 4: Dem Webbrowser beim Arbeiten zusehen
Öffne das »Network«-Tab der Developer-Console im Webbrowser, während der Browser eine REST-API benutzt (z.B. beim Lösen der vorigen Übung). Versuche, dich mit dem Werkzeug anzufreunden: Es ist eine unerlässliche Debug-Hilfe beim Arbeiten mit REST-APIs.
