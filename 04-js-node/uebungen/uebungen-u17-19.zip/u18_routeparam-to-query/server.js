// Übung 18: Queryparameter anstatt Routenparameter
// Stell dir vor, du müsstest eine bestehende Webanwendung portieren: ein CGI-Skript auf dem Server soll in Node.js neu geschrieben werden. Alle Links sollen aber weiterhin funktionieren.

// Schreibe die server.js Datei in nerdshop_2 so um, dass der Parameter id als Queryparameter anstatt als Routenparameter übergeben wird. Dazu musst du eine Route ohne Routenparameter definieren und auf den Wert des Parameters im req.query-Objekt anstelle des req.params-Objekts zugreifen.

// Rufe die Seite http://127.0.0.1:8081/product?id=8 auf, um die Änderung zu testen.
