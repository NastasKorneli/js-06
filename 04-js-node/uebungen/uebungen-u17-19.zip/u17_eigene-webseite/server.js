// Übung 17: Deine eigene Webseite
// Du hast sicher schon einmal ein Webseiten-Projekt mit HTML, CSS und JS-Dateien erstellt. Benutze die express.static(…)-Middleware, um die Seiten per HTTP auszuliefern.

// Erstelle neben der index.html mindestens 2 weitere HTML-Dokumente (z.B. about.html und contact.html)
