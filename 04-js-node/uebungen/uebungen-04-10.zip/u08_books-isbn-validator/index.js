// Übung 8: ISBNs aus einer CSV-Datei validieren

// Gegeben sei folgende CSV-Datei mit Titeln und ISBNs einiger Bücher — allerdings mit Fehlern: Zwei ISBNs sind ungültig.

// Schreibe ein Programm, das die Datei einliest und alle ISBNs validiert! Datensätze mit ungültigen ISBNs sollen ausgegeben werden.
